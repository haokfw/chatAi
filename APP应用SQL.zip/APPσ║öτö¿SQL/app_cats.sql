/*
 Navicat Premium Data Transfer

 Source Server         : NineAi-生产
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : 42.192.77.35:3306
 Source Schema         : nine-ai-gpt

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 21/06/2023 22:24:14
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for app_cats
-- ----------------------------
DROP TABLE IF EXISTS `app_cats`;
CREATE TABLE `app_cats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  `deletedAt` datetime(6) DEFAULT NULL COMMENT '删除时间',
  `name` varchar(255) NOT NULL COMMENT 'App分类名称',
  `des` varchar(255) NOT NULL COMMENT 'App分类描述信息',
  `coverImg` varchar(255) DEFAULT NULL COMMENT 'App分类封面图片',
  `order` int NOT NULL DEFAULT '100' COMMENT 'App分类排序、数字越大越靠前',
  `status` int NOT NULL DEFAULT '1' COMMENT 'App分类是否启用中 0：禁用 1：启用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_4c4a22756449e89d1c44d83944` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app_cats
-- ----------------------------
BEGIN;
INSERT INTO `app_cats` VALUES (1, '2023-05-02 01:25:30.661770', '2023-06-20 22:32:48.000000', NULL, '文案', '用于各个平台的文案创作', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (3, '2023-05-02 01:27:11.711756', '2023-06-20 22:32:51.000000', NULL, '工具', '用于提效的工具', 'https://img1.baidu.com/it/u=3477134069,925935400&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 800, 1);
INSERT INTO `app_cats` VALUES (6, '2023-06-19 03:14:37.215986', '2023-06-20 22:32:39.000000', NULL, '编程', '编程分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (7, '2023-06-19 03:15:17.143580', '2023-06-19 03:16:24.000000', NULL, '娱乐', '生活娱乐', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (8, '2023-06-19 03:16:07.293461', '2023-06-19 03:16:07.293461', NULL, '职业', '职业分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (9, '2023-06-19 03:16:39.718798', '2023-06-19 03:16:39.718798', NULL, '写作', '写作分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (10, '2023-06-19 03:16:53.103330', '2023-06-19 03:16:53.103330', NULL, '企业', '企业分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (11, '2023-06-19 03:17:06.709753', '2023-06-19 03:17:06.709753', NULL, '翻译', '翻译分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (12, '2023-06-19 03:17:20.315928', '2023-06-19 03:17:20.315928', NULL, '教育', '教育分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (13, '2023-06-19 03:17:29.180852', '2023-06-19 03:17:29.180852', NULL, '健康', '健康分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (14, '2023-06-19 03:17:36.860170', '2023-06-19 03:17:36.860170', NULL, '游戏', '游戏分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (15, '2023-06-19 03:18:09.574971', '2023-06-19 03:18:09.574971', NULL, '论文', '论文分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (16, '2023-06-19 03:18:57.011848', '2023-06-19 03:18:57.011848', NULL, '情感', '情感分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
INSERT INTO `app_cats` VALUES (17, '2023-06-19 03:19:05.569284', '2023-06-19 03:19:05.569284', NULL, '故事', '故事分类', 'https://img0.baidu.com/it/u=388635553,2482638928&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500', 100, 1);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
